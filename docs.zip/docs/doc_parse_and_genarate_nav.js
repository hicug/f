const p = require("./地大指南v0.1/prefix_info.json")
const fs = require("fs")
const path = require('path')
const {convertToPinyin} = require("./convert_to_pinyin")

/**
 * 3个重要变量
 * @type {string}
 */
const srcRoot = "./地大指南v0.1"//在此输入源文件夹路径
const tarRoot = ""//此处目标路径
const nav_js_path = "./.vuepress/config"//此处nav.js所在路径

/**
 *
 * @desc 异步深度循环删除目录
 * @param {string} dir 需要删除的目录
 * @param {function} callback 回调函数
 *
 * 实现思路：
 * 1.读取文件目录拿到当前目录所有的files
 * 2.调用next方法，并从0开始遍历files
 * 3.遍历结束，调用callbanck
 */
function rmdir(dir, callback) {
    fs.readdir(dir, (err, files) => {
        /**
         * @desc 内部循环遍历使用的工具函数
         * @param {Number} index 表示读取files的下标
         */
        function next(index) {
            // 如果index 等于当前files的时候说明循环遍历已经完毕，可以删除dir，并且调用callback
            if (index === files.length) return fs.rmdir(dir, callback)
            // 如果文件还没有遍历结束的话，继续拼接新路径，使用fs.stat读取该路径
            let newPath = path.join(dir, files[index])
            // 读取文件，判断是文件还是文件目录

            fs.stat(newPath, (err, stat) => {
                if (stat.isDirectory()) {
                    // 因为我们这里是深度循环，也就是说遍历玩files[index]的目录以后，才会去遍历files[index+1]
                    // 所以在这里直接继续调用rmdir，然后把循环下一个文件的调用放在当前调用的callback中
                    rmdir(newPath, () => next(index + 1))
                } else {
                    // 如果是文件，则直接删除该文件，然后在回调函数中调用遍历nextf方法，并且index+1传进去
                    fs.unlink(newPath, () => next(index + 1))
                }
            })
        }

        next(0)
    })
}

function rmdirSync(dir) {
    let arr = [dir]
    let current = null
    let index = 0

    while (current = arr[index++]) {
        // 读取当前文件，并做一个判断，文件目录分别处理
        let stat = fs.statSync(current)
        //如果文件是目录
        if (stat.isDirectory()) {
            //读取当前目录，拿到所有文件
            let files = fs.readdirSync(current)
            // 将文件添加到文件池
            arr = [...arr, ...files.map(file => path.join(current, file))]
        }
    }
    //遍历删除文件
    for (let i = arr.length - 1; i >= 0; i--) {
        // 读取当前文件，并做一个判断，文件目录分别处理
        let stat = fs.statSync(arr[i])
        // 目录和文件的删除方法不同
        if (stat.isDirectory()) {
            fs.rmdirSync(arr[i])
        } else {
            fs.unlinkSync(arr[i])
        }
    }
}

function printNum(num, length) {
    return (Array(length).join('0') + num).slice(-length);
}

/**
 *对Date的扩展，将 Date 转化为指定格式的String
 *月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符，
 *年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字)
 *例子：
 *(new Date()).Format("yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423
 *(new Date()).Format("yyyy-M-d h:m:s.S")      ==> 2006-7-2 8:9:4.18
 */
Date.prototype.format = function (fmt) {
    var o = {
        "M+": this.getMonth() + 1, //月份
        "d+": this.getDate(), //日
        "h+": this.getHours(), //小时
        "m+": this.getMinutes(), //分
        "s+": this.getSeconds(), //秒
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度
        "S": this.getMilliseconds() //毫秒
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}

/**
 * 创建对应路径，文件名不可有重复
 * @param pages
 * @return {{a:"path_a",b:"path_b"...}}
 */
function createPaths(pages) {
    let paths = {}, i = 0, j = 0;
    for (const catalog of pages.catalogs) {
        let cat_name = path.join(tarRoot, `${printNum(i + 1, 2)}.${catalog.cat_name}`)
        try {
            rmdirSync(cat_name)
            fs.mkdirSync(cat_name)
        } catch (e) {
            fs.mkdirSync(cat_name)
        }
        j = 0
        for (const pageElement of catalog.pages) {
            let page_title = `${printNum(j + 1, 2)}.${pageElement.page_title.split("——")[0]}`
            paths[pageElement.page_title] = path.join(cat_name, page_title + ".md")
            j += 1
        }
        i += 1
    }
    return paths
}

/**
 * 将源文件复制到路径中
 * @param paths
 * @param words
 */
function copyFiles(paths, words) {
    let n = 0;
    //复制文件
    for (const word of words) {
        const f_names = word.split(" —— ")
        if (f_names.length < 2) continue
        const src = f_names[1]
        const target = f_names[0]
        fs.copyFileSync(path.join(srcRoot, src), paths[target])
        n += 1
    }
}

/**
 * 给每个复制后的文件添加前缀
 * @param paths
 */
function addPrefix(paths) {
    for (const pathsKey in paths) {
        fs.readFile(paths[pathsKey], 'utf-8', (e, d) => {
            const date = new Date(Date.now())
            const separate = pathsKey.split("——")
            const title = separate[0];
            const author = separate.length > 1 ? pathsKey.split("——")[1] : " ";
            const prefix = `---\n` +
                `title: ${title}\n` +
                `author: ${author}\n` +
                `article: true\n` +
                `date: ${date.format("yyyy-MM-dd hh:mm:ss")}\n` +
                `permalink: /pages/${convertToPinyin(title)}/\n` +
                `article: false\n` +
                `---\n\n\n`
            const d2 = prefix + d
            fs.writeFileSync(paths[pathsKey], d2, 'utf-8')
        })
    }
}

/**
 * 生成nav.js文件
 * @param pages
 */
function genNav(pages) {
    let nav = [], i = 0, j = 0;
    nav.push({text: "首页", link: "/"})
    for (const catalog of pages.catalogs) {
        let cat_name = catalog.cat_name, item1 = {}, items = []
        item1.text = cat_name
        j = 0
        for (const pageElement of catalog.pages) {
            let page_title = pageElement.page_title, item2 = {}
            item2.text = page_title.split("——")[0]
            item2.link = `/pages/${convertToPinyin(page_title.split("——")[0])}/`
            items.push(item2)
            j += 1
        }
        item1.items = items
        nav.push(item1)
        i += 1
    }
    const nav_json = JSON.stringify(nav, null, 4);
    const nav_js = "const nav=require('./nav.json');module.exports={nav:nav}"
    try {
        fs.mkdirSync(nav_js_path)
    } catch (e) {
    }
    fs.writeFileSync(path.join(nav_js_path, "nav.json"), nav_json, "utf-8")
    fs.writeFileSync(path.join(nav_js_path, "nav.js"), nav_js, "utf-8")
    const a = 0
}

fs.readFile(path.join(srcRoot, "prefix_readme.md"), "utf-8", (e, d) => {
    if (!!e) throw e
    const words = d.split("\n")
    const pages = p.pages
    let paths = createPaths(pages)
    copyFiles(paths, words)
    addPrefix(paths)
    genNav(pages)
})
