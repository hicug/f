const {nav} = require("./config/nav");
module.exports = {
    title: '狗坏新生手册',
    description: '狗坏新生手册',
    base: '/',
    themeConfig: {
        nav,
        sidebar: 'auto', // 侧边栏配置
        sidebarDepth: 2, // 侧边栏显示2级
    }
};
